

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			PrintWriter out = response.getWriter();
			String url = "jdbc:mysql://localhost:3306/ecommerce";
			String userid = "root";
			String pwd = "Sql_1234";

			out.println("<html><body>");

			DBConnection conn = new DBConnection(url, userid, pwd);

			int id = Integer.parseInt(request.getParameter("id"));

			PreparedStatement ps = conn.getConnection().prepareStatement("select * from products where id = ?");
			ps.setInt(1, id);

			ResultSet rst = ps.executeQuery();

			if (rst.next()) {
				out.println(rst.getInt("ID") + ", " + rst.getString("name") + ", " + rst.getString("category") + ", "
						+ rst.getInt("stock_quantity") + "<Br>");
			} else {

				out.println("No Product Record Found for the entered Product ID = " + id + "<Br>");
			}

			rst.close();
			ps.close();

			out.println("</body></html>");
			conn.closeConnection();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * }
	 *
	 * /**
	 *
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
